import { useState } from "react";
import "./index.css";

const SCENARIOS = [
  {
    id: "coi",
    title: "Change of Income",
    desc: "Parent reports income change",
    icon: "💷",
    caller: {
      name: "David Thompson",
      tone: "Frustrated"
    },
    caseData: {
      ref: "CMS-2024-0847291",
      payingParent: "David Thompson",
      receivingParent: "Sarah Thompson",
      currentIncome: "£32,000",
      currentMaint: "£61.54/week",
      status: "Active",
      niNumber: "AB 12 34 56 C",
      dob: "14/03/1987"
    }
  },
  {
    id: "complaint",
    title: "Complaint Handling",
    desc: "Receiving parent unhappy with delays",
    icon: "⚠️",
    caller: {
      name: "Maria Santos",
      tone: "Angry"
    },
    caseData: {
      ref: "CMS-2024-0612334",
      payingParent: "James Wilson",
      receivingParent: "Maria Santos",
      currentIncome: "£28,500",
      currentMaint: "£43.85/week",
      status: "Collect & Pay",
      niNumber: "CD 56 78 90 D",
      dob: "22/07/1991"
    }
  }
];

const tabs = [
  { id: "case", label: "Case Overview" },
  { id: "income", label: "Income Details" },
  { id: "payments", label: "Payments" },
  { id: "notes", label: "Notes" }
];

function Sidebar({ scenarios, onSelect }) {
  return (
    <div className="sidebar">
      <div className="logo">CMS AI Factory</div>
      <h2>Training Scenarios</h2>

      {scenarios.map((s) => (
        <button className="scenario-card" key={s.id} onClick={() => onSelect(s)}>
          <div className="scenario-header">
            <span className="icon">{s.icon}</span>
            <div>
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
            </div>
          </div>

          <div className="meta">
            <span>{s.caller.name}</span>
            <span>{s.caller.tone}</span>
          </div>
        </button>
      ))}
    </div>
  );
}

function SiebelScreen({ scenario, activeTab }) {
  const data = scenario.caseData;

  return (
    <div className="siebel-window">
      <div className="toolbar">
        <div className="toolbar-left">
          <span>File</span>
          <span>Edit</span>
          <span>View</span>
          <span>Navigate</span>
        </div>

        <div className="toolbar-right">
          <span>Case Ref: {data.ref}</span>
        </div>
      </div>

      <div className="tabs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className={activeTab === tab.id ? "tab active" : "tab"}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="screen">
        {activeTab === "case" && (
          <div className="panel">
            <h3>Case Overview</h3>

            <div className="field-grid">
              <Field label="Case Reference" value={data.ref} />
              <Field label="Paying Parent" value={data.payingParent} />
              <Field label="Receiving Parent" value={data.receivingParent} />
              <Field label="NI Number" value={data.niNumber} />
              <Field label="DOB" value={data.dob} />
              <Field label="Income" value={data.currentIncome} />
              <Field label="Maintenance" value={data.currentMaint} />
              <Field label="Status" value={data.status} />
            </div>
          </div>
        )}

        {activeTab === "income" && (
          <div className="panel">
            <h3>Income Details</h3>

            <div className="form-row">
              <label>Current Income</label>
              <input placeholder="£32,000" />
            </div>

            <div className="form-row">
              <label>New Income</label>
              <input placeholder="Enter updated income" />
            </div>

            <div className="form-row">
              <label>Reason</label>
              <select>
                <option>Job Loss</option>
                <option>Promotion</option>
                <option>Universal Credit</option>
              </select>
            </div>

            <button className="primary-btn">Recalculate</button>
          </div>
        )}

        {activeTab === "payments" && (
          <div className="panel">
            <h3>Payment History</h3>

            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr>
                  <td>08/04/2026</td>
                  <td>£43.85</td>
                  <td className="red">Missed</td>
                </tr>

                <tr>
                  <td>01/04/2026</td>
                  <td>£43.85</td>
                  <td className="red">Missed</td>
                </tr>

                <tr>
                  <td>25/03/2026</td>
                  <td>£43.85</td>
                  <td className="green">Received</td>
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {activeTab === "notes" && (
          <div className="panel">
            <h3>Case Notes</h3>

            <textarea
              className="notes"
              placeholder="Enter case notes here..."
            />

            <button className="primary-btn">Save Note</button>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div className="field">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

export default function App() {
  const [selectedScenario, setSelectedScenario] = useState(SCENARIOS[0]);
  const [activeTab, setActiveTab] = useState("case");

  return (
    <div className="app-layout">
      <Sidebar scenarios={SCENARIOS} onSelect={setSelectedScenario} />

      <div className="main-content">
        <div className="header">
          <div>
            <h1>Siebel CMS Training Simulator</h1>
            <p>
              Simulated DWP CMS caseworker interface with realistic Siebel-style UI
            </p>
          </div>

          <div className="status">
            <span className="live-dot"></span>
            Training Mode Active
          </div>
        </div>

        <div className="quick-tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={activeTab === tab.id ? "quick-tab active" : "quick-tab"}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <SiebelScreen scenario={selectedScenario} activeTab={activeTab} />
      </div>
    </div>
  );
}
